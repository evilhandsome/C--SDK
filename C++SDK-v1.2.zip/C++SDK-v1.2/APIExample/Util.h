#include <string>
using namespace std;

std::wstring Mbcs2Unicode(const char* pMbs);
std::string Unicode2Mbcs(const wchar_t* pUnicode);